//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// buffer_pool_manager_instance.cpp
//
// Identification: src/buffer/buffer_pool_manager.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//
#include <iostream>
#include <fstream>
#include "buffer/buffer_pool_manager_instance.h"

#include "common/exception.h"
#include "common/macros.h"

namespace bustub {

BufferPoolManagerInstance::BufferPoolManagerInstance(size_t pool_size, DiskManager *disk_manager, size_t replacer_k,
                                                     LogManager *log_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager), log_manager_(log_manager)  {
  // we allocate a consecutive memory space for the buffer pool 
  std::ofstream debug_file("/bustub/build/buffer_debug.txt", std::ios::app);
  // 添加基础调试信息
    debug_file << "=== 构造函数开始 ===" << std::endl;
    debug_file << "pool_size: " << pool_size << std::endl;
    debug_file << "replacer_k: " << replacer_k << std::endl;

  pages_ = new Page[pool_size_];//Buffer里边的Page数组，其标号与Buffer的帧号一一对应，也就是说可以用frame_id直接作为Page数组的索引
  page_table_ = new ExtendibleHashTable<page_id_t, frame_id_t>(bucket_size_);
  replacer_ = new LRUKReplacer(pool_size, replacer_k);

  debug_file << "页面数组初始化完成，大小: " << pool_size_ << std::endl;
  debug_file << "页面表初始化完成" << std::endl;
  debug_file << "替换器初始化完成" << std::endl;

  // Initially, every page is in the free list.
  debug_file << "初始化空闲列表，帧数: " << pool_size_ << std::endl;
  for (size_t i = 0; i < pool_size_; ++i) {
    free_list_.emplace_back(static_cast<int>(i));//把size_t显式转换为 static_cast<int>，更安全
    //这里说明frame_id并没有用什么很复杂的类来存储，只是用简单整型就存下来了。
  }

  debug_file << "free_list 初始大小: " << free_list_.size() << std::endl;
  debug_file << "=== 构造函数完成 ===" << std::endl;

  // TODO(students): remove this line after you have implemented the buffer pool manager
  /* 
  throw NotImplementedException(
      "BufferPoolManager is not implemented yet. If you have finished implementing BPM, please remove the throw "
      "exception line in `buffer_pool_manager_instance.cpp`.");
  */
  
}

BufferPoolManagerInstance::~BufferPoolManagerInstance() {
  delete[] pages_;
  delete page_table_;
  delete replacer_;
}

auto BufferPoolManagerInstance::NewPgImp(page_id_t *page_id) -> Page * { 
//创建一个新的空白页放入Buffer，并返回该页的page_id和内存指针。
  system("echo 'NewPgImp被调用' >> /bustub/build/simple_debug.log");
  std::ofstream debug_file("/bustub/build/buffer_debug.txt", std::ios::app);
  std::scoped_lock lock(latch_);

 

  // 添加最简单的调试信息
  debug_file << ">>> NewPgImp 被调用 <<<" << std::endl;

  debug_file << "=== NewPgImp 开始 ===" << std::endl;
  debug_file << "free_list_.size(): " << free_list_.size() << std::endl;
  debug_file << "pool_size_: " << pool_size_ << std::endl;

  frame_id_t selected_frame_id = -1;  // 用于接收被选中的frame_id
  bool found_frame = false;

  //接下来应该从free_list_里边找找有没有空闲帧，没有再调用LRU算法
  if(free_list_.empty()){//free_list是空的，意味着没有空闲帧，可以调用LRU算法
    
    debug_file << "free_list 为空，尝试驱逐" << std::endl;
    if (replacer_->Evict(&selected_frame_id)) {//Evict函数返回True, 代表着这个id的帧就是被置换的帧
    // 成功选择了一个帧，Evict函数会自己选择然后传给selected_frame_id的
      debug_file << "成功驱逐帧: " << selected_frame_id << std::endl;
      //1.处理被驱逐的页面
      Page* victim_page = &pages_[selected_frame_id];//现在page数组的对应页还是那个被驱逐的页，还没有更新 
      debug_file << "被驱逐页面的 page_id: " << victim_page->GetPageId() << std::endl;
      debug_file << "页面是否脏: " << victim_page->IsDirty() << std::endl;
      
      if (victim_page->IsDirty()) {
        debug_file << "写回脏页到磁盘" << std::endl;
        disk_manager_->WritePage(victim_page->GetPageId(), victim_page->GetData());//如果页被修改过，则需要先写回磁盘！
        victim_page->is_dirty_ = false;  // 清除脏标志，毕竟victim_page可不是变量，而是一个指针，所以它并不是临时副本，对它的相关修改是真的会影响到page数组的！
      }
      //2.从页面表中移除旧映射
      page_table_->Remove(victim_page->GetPageId());  // 移除旧映射
      found_frame = true;
    }
    
  }
  else {//free_list非空
      debug_file << "从 free_list 获取帧" << std::endl;
      selected_frame_id = free_list_.front();  // 取第一个可用帧
      free_list_.pop_front();  // 从空闲列表移除  
      found_frame = true; 
      debug_file << "获取的帧 ID: " << selected_frame_id << std::endl;
  }

  //如果freelist的两种情况都失败，则返回nullptr
  if (!found_frame) {
    debug_file << "!!! 没有找到可用帧，返回 nullptr !!!" << std::endl;
    *page_id = INVALID_PAGE_ID;  // 分配失败
    return nullptr;
  }
   

  *page_id = AllocatePage();//获取页面id，用于创建新的页面
  debug_file << "分配的新页面 ID: " << *page_id << std::endl;


  //更新page_table_
  //接着存储新的页与新的帧的映射关系
  page_table_->Insert(*page_id, selected_frame_id);
  debug_file << "页面表插入完成" << std::endl;

  //重置新帧的数据
  Page* newpage = &pages_[selected_frame_id];
  newpage->ResetMemory();  // 清空数据
  newpage->page_id_ = *page_id;  // 设置新页面ID
  newpage->pin_count_ = 1;  // 设置pin计数
  newpage->is_dirty_ = false;  // 清除脏标志
    
  //更新新页面的时间戳和驱逐位
  replacer_->RecordAccess(selected_frame_id);
  replacer_->SetEvictable(selected_frame_id, false);//锁定该帧，不可驱逐
    
  debug_file << "=== NewPgImp 成功，返回页面 ===" << std::endl;  
  return newpage; 
}

auto BufferPoolManagerInstance::FetchPgImp(page_id_t page_id) -> Page * {
//在Buffer找指定id的页面，找不到就去磁盘里找。  

  std::scoped_lock lock(latch_);

  frame_id_t frame_id;
  if (page_table_->Find(page_id, frame_id)) {
    // 找到页面，更新替换器状态并返回
    Page* page = &pages_[frame_id];
    replacer_->RecordAccess(frame_id);
    replacer_->SetEvictable(frame_id, false);

    page->pin_count_++;  //增加pin计数
    return page;
  }

  //能走到这里，函数还没返回就说明在Buffer找不到了，那接下来就去磁盘里边找
  frame_id_t selected_frame_id;  // 可用帧的frame_id   

  //如果本来就有空闲帧的话,那么直接用作可用帧就好了
  if(!free_list_.empty()){
    selected_frame_id = free_list_.front();  // 取第一个可用帧
    free_list_.pop_front();  // 从空闲列表移除   
  }
  //如果没有空闲帧，尝试用LRU算法腾出一个帧
  else  if (replacer_->Evict(&selected_frame_id)) {// 成功选择了一个帧，Evict函数会自己选择然后传给selected_frame_id的 
    Page* victim_page = &pages_[selected_frame_id];//现在page数组的对应页还是那个被驱逐的页，还没有更新

    if (victim_page->IsDirty()) {
      disk_manager_->WritePage(victim_page->GetPageId(), victim_page->GetData());//如果页被修改过，则需要先写回磁盘！
      victim_page->is_dirty_ = false;  // 清除脏标志，毕竟victim_page可不是变量，而是一个指针，所以它并不是临时副本，对它的相关修改是真的会影响到page数组的！
    }
    page_table_->Remove(victim_page->GetPageId());  // 移除旧映射
  }
  else {//既没有空闲帧，也没有可腾出来的帧，应该直接返回空指针
    return nullptr;//如果这里不返回的话，那么下面的selected_frame_id将会是空指针，会出问题！
  }
    
    
  //已经获取可用帧的id：selected_frame_id，接下来把指定页放入可用帧，然后返回
  //现在有了可用帧，从磁盘读取页面数据
  Page* page = &pages_[selected_frame_id];
  disk_manager_->ReadPage(page_id, page->GetData());

  //更新page_table_
  page_table_->Insert(page_id, selected_frame_id);//接着存储新的页与新的帧的映射关系

  //更新页面元数据
  page->page_id_ = page_id;
  page->pin_count_ = 1; 
  page->is_dirty_ = false;
  
  //更新替换器
  replacer_->RecordAccess(selected_frame_id);
  replacer_->SetEvictable(selected_frame_id, false);//锁定该帧，不可驱逐

  return page;//已将指定页放入帧，现在返回指定页
}

auto BufferPoolManagerInstance::UnpinPgImp(page_id_t page_id, bool is_dirty) -> bool {
//UnpinPgImp的主要作用是当一个页面使用完毕后，通知缓冲池管理器可以释放对该页面的"固定"状态，顺便处理这个页的脏位。
system("echo 'UnpinPgImp被调用' >> /bustub/build/simple_debug.log");  
  //线程安全保护
  std::scoped_lock lock(latch_);

  //首先检查page_id是否有效
  if (page_id == INVALID_PAGE_ID) {
    return false;
  }  

  //先找页面，然后unpin
  frame_id_t frame_id;
  if (!page_table_->Find(page_id, frame_id)) {
    return false;// 页面不在缓冲池中
  }

  // 检查当前是否被固定（pin_count > 0）
  if (pages_[frame_id].pin_count_ <= 0) {
    return false;  // 页面未被固定，不能unpin
  }

  if (pages_[frame_id].pin_count_ == 0) {
    replacer_->SetEvictable(frame_id, true);
  }
    
  // 然后减少固定计数
  pages_[frame_id].pin_count_--;


  //如果已修改
  pages_[frame_id].is_dirty_ = pages_[frame_id].is_dirty_ || is_dirty;
  //注意：不能直接赋值，应该使用逻辑或，因为页面可能已经是脏的
  //所以若没有修改，则该页的脏位不予改变

   return true;
}

auto BufferPoolManagerInstance::FlushPgImp(page_id_t page_id) -> bool { 
//FlushPgImp是用来将脏页写回磁盘的，保持内存与磁盘数据一致
  //线程安全保护
  std::scoped_lock lock{latch_};

  //先找到页面
  frame_id_t frame_id;
  if (!page_table_->Find(page_id, frame_id)) {
    return false;// 页面不在缓冲池中
  }
  //这里就不用临时变量了，因为我们需要对原件进行修改

  //接着写回磁盘
  if(pages_[frame_id].IsDirty()){
    disk_manager_->WritePage(page_id, pages_[frame_id].GetData());//被修改过则将内容写回磁盘
  }

  pages_[frame_id].is_dirty_=false;//内存与磁盘数据已经一致，重置脏位

  return true; 
}

void BufferPoolManagerInstance::FlushAllPgsImp() {
// 遍历buffer pool中的所有frame
  std::scoped_lock lock(latch_);

  for (size_t i = 0; i < pool_size_; i++) {
    Page* page = &pages_[i];
        
    // 检查页面是否有效（有分配的page_id）
    if (page->GetPageId() != INVALID_PAGE_ID) {
      // 调用FlushPgImp刷新当前页面
      FlushPgImp(page->GetPageId());
    }        
  }    
}

auto BufferPoolManagerInstance::DeletePgImp(page_id_t page_id) -> bool {  
  //保证线程安全
  std::scoped_lock lock{latch_};

  //首先检查page_id是否有效
  if (page_id == INVALID_PAGE_ID) {
    return false;
  } 

  //查找该页面是否在Buffer里
  frame_id_t frame_id;
  if (!page_table_->Find(page_id, frame_id)) {
    return true;// 页面不在Buffer中，返回true，因为目的已经达成
  }
  
  if (pages_[frame_id].GetPinCount() > 0) {
    return false;  // 页面正在被使用，不能删除
  }

  //没有返回说明在Buffer里边
  if(pages_[frame_id].IsDirty())
  {
    disk_manager_->WritePage(page_id, pages_[frame_id].GetData());//脏页写回磁盘
    pages_[frame_id].is_dirty_ = false;  // 手动清除脏标志
    //不用FlushPgImp函数是因为避免线程死锁和线程安全的二选一难题
  }

  //重置页面元数据
  pages_[frame_id].ResetMemory();
  pages_[frame_id].page_id_ = INVALID_PAGE_ID;
  pages_[frame_id].pin_count_ = 0;
  pages_[frame_id].is_dirty_ = false;

  //从 page_table中删除条目
  page_table_->Remove(page_id);
  //将帧加入空闲列表
  free_list_.push_back(frame_id);
  //更新替换器
  replacer_->Remove(frame_id);

  return true;
}

auto BufferPoolManagerInstance::AllocatePage() -> page_id_t { 
  //std::scoped_lock lock{latch_};
  std::ofstream debug_file("/bustub/build/buffer_debug.txt", std::ios::app);
  debug_file << "AllocatePage 被调用，当前 next_page_id_: " << next_page_id_ << std::endl;
  page_id_t new_id = next_page_id_++;
  debug_file << "分配的新 ID: " << new_id << std::endl;
  return new_id;
}


/*
auto BufferPoolManagerInstance::GetPoolSize() -> size_t {
        return pool_size_;
}
*/



}  // namespace bustub


//测试用的命令

/*
大测试：

cd build
make buffer_pool_manager_instance_test > make_output.log 2>&1
./test/buffer_pool_manager_instance_test > test_output.txt 2>&1


简单测试：

./test/buffer_pool_manager_instance_test --gtest_filter="*SampleTest*" > sample_test_output.txt 2>&1

*/