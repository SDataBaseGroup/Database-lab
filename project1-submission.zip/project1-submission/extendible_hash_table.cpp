#include <functional>
#include <list>
#include <utility>

#include "container/hash/extendible_hash_table.h"
#include "storage/page/page.h"

namespace bustub {

template <typename K, typename V>
ExtendibleHashTable<K, V>::ExtendibleHashTable(size_t bucket_size) : bucket_size_(bucket_size) {
  dir_.push_back(std::make_shared<Bucket>(bucket_size_, 0));
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::IndexOf(const K &key) -> size_t {
  size_t mask = (1ULL << global_depth_) - 1ULL;
  return std::hash<K>()(key) & mask;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetGlobalDepth() const -> int {
  std::scoped_lock<std::mutex> g(latch_);
  return global_depth_;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetLocalDepth(int index) const -> int {
  std::scoped_lock<std::mutex> g(latch_);
  return dir_[index]->GetDepth();
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetNumBuckets() const -> int {
  std::scoped_lock<std::mutex> g(latch_);
  return num_buckets_;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Find(const K &key, V &val) -> bool {
  std::scoped_lock<std::mutex> g(latch_);
  return dir_[IndexOf(key)]->Find(key, val);
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Remove(const K &key) -> bool {
  std::scoped_lock<std::mutex> g(latch_);
  return dir_[IndexOf(key)]->Remove(key);
}

template <typename K, typename V>
void ExtendibleHashTable<K, V>::Insert(const K &key, const V &val) {
  std::scoped_lock<std::mutex> g(latch_);

  while (dir_[IndexOf(key)]->IsFull()) {
    auto i = IndexOf(key);
    auto old_bucket = dir_[i];

    if (old_bucket->GetDepth() == global_depth_) {
      int prev = dir_.size();
      global_depth_++;
      dir_.resize(prev << 1);
      for (int k = 0; k < prev; k++) dir_[k + prev] = dir_[k];
    }

    int mask = 1 << old_bucket->GetDepth();
    auto b0 = std::make_shared<Bucket>(bucket_size_, old_bucket->GetDepth() + 1);
    auto b1 = std::make_shared<Bucket>(bucket_size_, old_bucket->GetDepth() + 1);

    for (auto &p : old_bucket->GetItems()) {
      auto h = std::hash<K>()(p.first);
      ((h & mask) ? b1 : b0)->Insert(p.first, p.second);
    }

    num_buckets_++;

    for (size_t k = 0; k < dir_.size(); k++) {
      if (dir_[k] == old_bucket) dir_[k] = ((k & mask) ? b1 : b0);
    }
  }

  auto idx = IndexOf(key);
  auto &bucket = dir_[idx];

  for (auto &p : bucket->GetItems()) {
    if (p.first == key) {
      p.second = val;
      return;
    }
  }

  bucket->Insert(key, val);
}

template <typename K, typename V>
ExtendibleHashTable<K, V>::Bucket::Bucket(size_t sz, int d) : size_(sz), depth_(d) {}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Find(const K &key, V &val) -> bool {
  for (auto &p : list_) {
    if (p.first == key) {
      val = p.second;
      return true;
    }
  }
  return false;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Remove(const K &key) -> bool {
  for (auto &p : list_) {
    if (p.first == key) {
      list_.remove(p);
      return true;
    }
  }
  return false;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Insert(const K &key, const V &val) -> bool {
  if (list_.size() >= size_) return false;
  list_.push_back({key, val});
  return true;
}

template class ExtendibleHashTable<page_id_t, Page *>;
template class ExtendibleHashTable<Page *, std::list<Page *>::iterator>;
template class ExtendibleHashTable<int, int>;
template class ExtendibleHashTable<int, std::string>;
template class ExtendibleHashTable<int, std::list<int>::iterator>;

}  // namespace bustub
