#include "buffer/lru_k_replacer.h"
#include <stdexcept>

namespace bustub {

    // 构造函数，进行参数检查
    LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k)
        : max_frames_(num_frames), k_value_(k) {
        // 检查K值是否有效
        if (k == 0) {
            throw std::invalid_argument("K值不能为0");
        }
    }

    // 淘汰帧：选择后向K距离最大的帧
    auto LRUKReplacer::Evict(int* frame_id) -> bool {
        std::lock_guard<std::mutex> guard(lock_);

        // 如果没有帧可淘汰，直接返回
        if (records_.empty()) {
            return false;
        }

        int best_frame = -1;
        size_t max_distance = 0;
        size_t oldest_time = 0;

        // 遍历所有帧记录，找到最适合淘汰的
        for (const auto& entry : records_) {
            int frame = entry.first;
            const FrameRecord& record = entry.second;

            // 跳过不可淘汰的帧
            if (!record.evictable) {
                continue;
            }

            // 计算当前帧的K距离
            size_t distance = CalcKDistance(record);
            size_t compare_time = (record.history.size() < k_value_) ?
                record.first_time : record.history.front();

            // 选择逻辑：优先选K距离大的，相同则选时间早的
            if (best_frame == -1) {
                best_frame = frame;
                max_distance = distance;
                oldest_time = compare_time;
            }
            else if (distance > max_distance) {
                best_frame = frame;
                max_distance = distance;
                oldest_time = compare_time;
            }
            else if (distance == max_distance && compare_time < oldest_time) {
                best_frame = frame;
                oldest_time = compare_time;
            }
        }

        // 如果找到候选帧，进行淘汰
        if (best_frame != -1) {
            *frame_id = best_frame;
            records_.erase(best_frame);
            return true;
        }

        return false;
    }

    // 记录帧访问
    void LRUKReplacer::RecordAccess(int frame_id) {
        std::lock_guard<std::mutex> guard(lock_);

        // 检查帧ID是否在有效范围内
        if (frame_id < 0 || static_cast<size_t>(frame_id) >= max_frames_) {
            return;
        }

        FrameRecord& record = records_[frame_id];

        // 记录当前访问时间
        record.history.push(current_time_);

        // 记录第一次访问时间
        if (record.history.size() == 1) {
            record.first_time = current_time_;
        }

        // 保持最近K次访问记录
        if (record.history.size() > k_value_) {
            record.history.pop();
        }

        // 时间戳递增
        current_time_++;
    }

    // 设置帧是否可淘汰
    void LRUKReplacer::SetEvictable(int frame_id, bool set_evictable) {
        std::lock_guard<std::mutex> guard(lock_);

        auto it = records_.find(frame_id);
        if (it != records_.end()) {
            it->second.evictable = set_evictable;
        }
    }

    // 移除帧
    void LRUKReplacer::Remove(int frame_id) {
        std::lock_guard<std::mutex> guard(lock_);
        records_.erase(frame_id);
    }

    // 返回可淘汰帧数量
    auto LRUKReplacer::Size() -> size_t {
        std::lock_guard<std::mutex> guard(lock_);

        size_t count = 0;
        for (const auto& entry : records_) {
            if (entry.second.evictable) {
                count++;
            }
        }
        return count;
    }

    // 计算后向K距离
    auto LRUKReplacer::CalcKDistance(const FrameRecord& record) -> size_t {
        // 访问次数不足K次，返回最大值（表示无穷大）
        if (record.history.size() < k_value_) {
            return std::numeric_limits<size_t>::max();
        }

        // 计算当前时间与第K次访问时间的差值
        return current_time_ - record.history.front();
    }

} // namespace bustub