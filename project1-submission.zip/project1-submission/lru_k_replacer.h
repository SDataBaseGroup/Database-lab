#ifndef LRU_K_REPLACER_H
#define LRU_K_REPLACER_H

#include <unordered_map>
#include <queue>
#include <mutex>
#include <limits>

namespace bustub {

    // LRU-K页面替换算法
    // 用于数据库缓冲池管理，根据访问历史决定淘汰哪个页面
    class LRUKReplacer {
    public:
        // 构造函数，初始化最大帧数和K值
        LRUKReplacer(size_t num_frames, size_t k);

        // 析构函数
        ~LRUKReplacer() = default;

        // 淘汰一个帧，成功返回true，帧ID存入frame_id
        auto Evict(int* frame_id) -> bool;

        // 记录帧的访问，更新访问历史
        void RecordAccess(int frame_id);

        // 设置帧是否可被淘汰
        void SetEvictable(int frame_id, bool set_evictable);

        // 从替换器中移除帧
        void Remove(int frame_id);

        // 返回当前可淘汰的帧数量
        auto Size() -> size_t;

    private:
        // 每个帧的访问记录
        struct FrameRecord {
            std::queue<size_t> history;    // 访问时间历史记录
            bool evictable = false;        // 是否可淘汰
            size_t first_time = 0;         // 第一次访问时间
        };

        size_t max_frames_;              // 最大帧数
        size_t k_value_;                 // K值
        size_t current_time_ = 0;        // 当前时间戳
        std::unordered_map<int, FrameRecord> records_;  // 存储所有帧记录
        std::mutex lock_;                // 线程安全锁

        // 计算帧的后向K距离
        auto CalcKDistance(const FrameRecord& record) -> size_t;
    };

} // namespace bustub

#endif